# Register allocator regression cases: condition/body aliasing

These six cases extend the pattern in `03_cond_body_aliasing.cpp`. They are intended to stress the allocator's handling of values changed by a `while` condition and then read or changed again in the body.

## Cases

- `07_nested_cond_body_aliasing.cpp` — three nested loops; inner loop body mutates both ancestor counters after using them; many loop-carried variables remain live across loop boundaries.
- `08_four_level_counter_alias_pressure.cpp` — four nested loops and 20 long-lived data variables; each loop counter is changed in its condition and again in its body, including ancestor counters after nested loops.
- `09_condition_limit_body_write.cpp` — the condition updates `i` and compares it against `limit`; the body updates `limit`, while an inner condition similarly reads the body-mutated `floor` and mutates `j` again.
- `10_lvalue_and_step_alias.cpp` — condition LHS (`gate`) and RHS operand (`step`) are both changed in the body; the nested condition also depends on `step`, which its body changes.
- `11_zero_trip_and_sibling_reentry.cpp` — zero-trip loop followed by reads of its condition-updated counter, nested loops that modify ancestor counters, then sibling loops to stress exit/re-entry state.
- `12_condition_lhs_rhs_mutated.cpp` — `x` is assigned inside the condition using `y`, and the body updates `x`, `y`, and `bound`; a nested loop repeats the same alias pattern with `u` and `v`.

## Native reference results

The expected return values below were obtained by compiling each source with the local native C++ compiler (unoptimized, `-O0`). They are reference values for differential testing, not proof that the custom compiler has already passed these tests.

| File | Expected `test()` return |
|---|---:|
| `07_nested_cond_body_aliasing.cpp` | 295 |
| `08_four_level_counter_alias_pressure.cpp` | 555 |
| `09_condition_limit_body_write.cpp` | 368 |
| `10_lvalue_and_step_alias.cpp` | 489 |
| `11_zero_trip_and_sibling_reentry.cpp` | 238 |
| `12_condition_lhs_rhs_mutated.cpp` | 904 |

## Suggested use

Run every file through the same compiler pipeline used for `03_cond_body_aliasing.cpp`, and compare the generated allocator variants against the native reference value. Keep each failure's source and generated assembly so a mismatch can be reproduced exactly.
