# VSL Random Differential Testing Tool

This Python tool generates random VSL programs, compiles each program with the host `g++` as a reference and with VSC, then compares their printed results.

## What this version tests

- `break` and `continue` appear only inside a `while` body, where they are syntactically valid.
- They can be generated directly as statements in a loop body; they do not have to be wrapped in `if/else`.
- They can also be generated inside nested `if/else` branches. They follow C/C++ semantics and target the innermost enclosing loop.
- **One or two random statements are deliberately generated immediately after a `break` or `continue` whenever the statement budget permits.** These statements may be assignments, `if/else`, or nested `while` statements. They are unreachable along any execution path that takes that `break`/`continue`, but the compiler still has to parse and process the source. This helps exercise dead-code handling and control-flow/register-state bookkeeping.
- The summary reports total `break`/`continue` counts, direct loop-body counts, and how many statements were deliberately emitted after loop-control statements.
- The generator avoids the comma operator and unary `+`/`-`.
- Each loop uses its own counter, decremented in its condition. Random assignments do not modify those counters, so `continue` cannot prevent the loop condition from making progress.

## Run

From your VSC repository, with `./build/vsc` available:

```bash
python3 vsl_diff_fuzz.py --cases 100 --seed 1
```

For a stronger run:

```bash
python3 vsl_diff_fuzz.py --cases 1000 --seed 1 --vars-min 8 --vars-max 140 --depth 30 --budget 320
```

Your existing shell wrapper can remain unchanged. Keep the printed seed and the artifacts saved under `fuzz_failures/` if a case fails.

Generate source files only:

```bash
python3 vsl_diff_fuzz.py --generate-only --cases 20 --seed 1 --out generated_cases
```

## Validation performed for this update

- Python syntax compilation passed.
- 100 generated samples passed GCC C++ syntax checking.
- The same 100 samples compiled and executed with GCC without reference-side failures.

The generated samples have not been run through the user's VSC build as part of this package creation. Differential testing passing is evidence for tested inputs, not a proof of compiler correctness.
