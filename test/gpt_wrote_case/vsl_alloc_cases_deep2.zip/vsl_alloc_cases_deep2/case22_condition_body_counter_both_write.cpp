int test() {
    int n = 0, total = 0, x = 3, y = 7, z = 11;
    while ((n = n + 1) <= 7) {
        if (n < 4) {
            total = total + n;
            x = x + y;
            n = n + 1;
        } else {
            total = total + x;
            y = y + z;
        }
        z = z + total;
    }
    return n + total + x + y + z;
}
