int test() {
    int i = 0, j = 0;
    int a = 1, b = 2, c = 3, d = 4, e = 5, f = 6, g = 7;
    int h = 8, p = 9, q = 10, r = 11, s = 12, t = 13, u = 14;
    while ((i = i + 1) <= 3) {
        if (i < 3) {
            a = a + h;
            b = b + p;
            c = c + q;
            d = d + r;
            e = e + s;
        } else {
            f = f + t;
            g = g + u;
            h = h + a;
            p = p + b;
            q = q + c;
        }
        j = 0;
        while ((j = j + 1) <= 2) {
            if (j < i) {
                r = r + d;
                s = s + e;
                t = t + f;
            } else {
                u = u + g;
                a = a + j;
                b = b + u;
            }
        }
        c = c + t;
        d = d + s;
        e = e + r;
    }
    return i + j + a + b + c + d + e + f + g + h + p + q + r + s + t + u;
}
