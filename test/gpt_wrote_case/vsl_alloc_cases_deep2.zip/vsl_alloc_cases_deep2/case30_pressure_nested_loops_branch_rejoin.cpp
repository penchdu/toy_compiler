int test() {
    int i = 0, j = 0, k = 0;
    int a = 2, b = 4, c = 6, d = 8, e = 10, f = 12;
    int p = 14, q = 16, r = 18, s = 20;
    while ((i = i + 1) <= 3) {
        if (i < 3) {
            j = 0;
            while ((j = j + 1) <= 2) {
                a = a + b;
                c = c + d;
                p = p + j;
            }
            if (a > c) {
                e = e + p;
                q = q + a;
            } else {
                f = f + q;
                r = r + c;
            }
        } else {
            k = 0;
            while ((k = k + 1) <= 3) {
                b = b + c;
                d = d + e;
                s = s + k;
            }
            if (b > d) {
                p = p + s;
                e = e + b;
            } else {
                q = q + s;
                f = f + d;
            }
        }
        a = a + r;
        c = c + s;
        e = e + q;
    }
    return i + j + k + a + b + c + d + e + f + p + q + r + s;
}
