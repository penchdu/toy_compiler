# VSL x64 allocator 深水区回归用例（case21–case30）

本目录包含 10 个独立测试程序，入口均为 `int test()`。请每个 `.cpp` 单独交给 VSL 编译器，不要把这些文件链接成同一个程序。用例不包含 `continue`、`break`、数组、指针或函数调用。

下面的预期返回值已用宿主机 GCC 编译执行相同的 `test()` 源码核对；它们是语义参考值，并不代表已经在 VSL 编译器上实测通过。

| 文件 | 预期返回值 | 重点覆盖 |
|---|---:|---|
| `case21_loop_exit_then_post_branch.cpp` | 378 | 循环退出后立即分支；循环内和循环后的值都继续参与计算 |
| `case22_condition_body_counter_both_write.cpp` | 345 | 条件与循环体交替修改同一个计数器，且其余变量持续读写 |
| `case23_inner_loop_feeds_sibling_branch.cpp` | 2196 | 内层循环更新的多组变量被外层后续分支读取 |
| `case24_zero_trip_nested_loop_after_dirty_branch.cpp` | 514 | 一个分支里的内层循环零次执行，分支后继续使用被修改的值 |
| `case25_sibling_loops_mutate_outer_counter.cpp` | 325 | 同层兄弟循环共享状态，其中一个内层循环还会修改外层计数器 |
| `case26_pressure_fourteen_live_values.cpp` | 1733 | 14 个长期变量跨分支与内层循环存活，制造寄存器压力 |
| `case27_dirty_outer_values_cross_two_inner_loops.cpp` | 10191 | 外层变量穿过两个连续内层循环，在深层分支被读写后再汇合 |
| `case28_four_level_loop_every_level_writes.cpp` | 1097861 | 四层循环中每一层都修改跨层使用的变量，包含深层分支 |
| `case29_loop_test_value_modified_by_both_branches.cpp` | 364 | 条件变量由循环体中的不同分支继续修改，退出后使用状态 |
| `case30_pressure_nested_loops_branch_rejoin.cpp` | 1267 | 两个外层分支各自有内层循环，分支合流后继续读写多组变量 |

## 建议执行顺序

1. 先运行 `case22` 和 `case29`，重点观察循环条件值在循环体被再次修改后的状态。
2. 再运行 `case24` 和 `case25`，检查零次循环以及内层修改外层计数器的情况。
3. 最后运行 `case26`、`case27`、`case28`、`case30`，集中检查高寄存器压力、跨层 live range、spill 和分支合流。

发生失败时，请保留对应的源文件、生成的 `.s` 和完整报错。判断 spill 时应查看实际栈读写指令和控制流位置，而不只统计 `#victim` 注释。
