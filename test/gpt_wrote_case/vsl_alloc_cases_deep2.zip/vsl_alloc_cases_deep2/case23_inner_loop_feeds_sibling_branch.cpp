int test() {
    int i = 0, j = 0;
    int a = 2, b = 3, c = 5, d = 7, e = 11, f = 13;
    while ((i = i + 1) <= 4) {
        j = 0;
        while ((j = j + 1) <= 3) {
            if (j < i) {
                a = a + b;
                b = b + j;
            } else {
                c = c + a;
                d = d + i;
            }
        }
        if (a > d) {
            e = e + c;
            f = f + a;
        } else {
            c = c + e;
            d = d + f;
        }
        b = b + e;
    }
    return i + j + a + b + c + d + e + f;
}
