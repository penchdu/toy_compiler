int test() {
    int i = 0, k = 0;
    int a = 1, b = 2, c = 4, d = 8, sum = 3;
    while ((i = i + 1) <= 3) {
        k = 0;
        while ((k = k + 1) <= 2) {
            a = a + i;
            b = b + k;
        }
        k = 0;
        while ((k = k + 1) <= 3) {
            c = c + a;
            if (k < 2) {
                i = i + 1;
            } else {
                b = b + c;
            }
            d = d + k;
        }
        sum = sum + a + b;
    }
    return i + k + a + b + c + d + sum;
}
